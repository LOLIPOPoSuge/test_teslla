(function() {
    window['optimizely'] = window['optimizely'] || [];
    window['optimizely'].push(['activateGeoDelayedExperiments', {
        'location': {
            'city': "CRAIOVA",
            'continent': "EU",
            'country': "RO",
            'region': "DJ",
            'dma': ""
        },
        'ip': "86.121.242.192"
    }]);
})

()

;